package com.example.mydrum;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    MediaPlayer kick,dapli,clap,snare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        kick = MediaPlayer.create(MainActivity.this, R.raw.kick);
        dapli = MediaPlayer.create(MainActivity.this, R.raw.dapli);
        clap = MediaPlayer.create(MainActivity.this, R.raw.clap);
        snare = MediaPlayer.create(MainActivity.this, R.raw.snare);
    }
    public  void  playKick(View view){
        kick.start();
    }
    public  void  playClap(View view){
        clap.start();
    }
    public  void  playDapli(View view){
        dapli.start();
    }
    public  void  playSnare(View view){
        snare.start();
    }
}
